Alpha, first text.
