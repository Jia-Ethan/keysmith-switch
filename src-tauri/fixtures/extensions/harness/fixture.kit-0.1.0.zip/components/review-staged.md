---
description: Review the staged change
argument-hint: "[path]"
---

Review $ARGUMENTS.
