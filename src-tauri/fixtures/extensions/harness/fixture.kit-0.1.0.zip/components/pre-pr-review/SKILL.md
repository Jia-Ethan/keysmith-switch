---
name: pre-pr-review
description: Review the change before a pull request.
---

# Pre-PR review

Read the whole diff first. See [checklist.md](checklist.md).
