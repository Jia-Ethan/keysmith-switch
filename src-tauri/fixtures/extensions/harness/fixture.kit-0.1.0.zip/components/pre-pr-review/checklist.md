# Severities

- blocker
- should-fix
- nit
