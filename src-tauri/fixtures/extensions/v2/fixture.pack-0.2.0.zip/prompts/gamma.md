Gamma, new in 0.2.0.
