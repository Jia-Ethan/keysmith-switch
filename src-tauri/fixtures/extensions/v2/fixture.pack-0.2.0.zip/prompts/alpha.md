Alpha, second text.
